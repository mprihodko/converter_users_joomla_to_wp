<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width">
	<?php styles(array(
		'style'=>'/assets/childstyle.css'
	));?>	
</head>
<body>
<div id="page" class="hfeed site">	
		<header id="masthead" class="site-header" role="banner">
			<div class="site-branding">
				<h1>IMPORT JOOMLA USERS TO WORDPRESS</h1>
			</div><!-- .site-branding -->
		</header><!-- .site-header -->
	<div id="content" class="site-content"><!-- .site-content -->