</div><!-- .site-content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info">
			
		
		</div><!-- .site-info -->
		<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>	
		<script type="text/javascript" src="<?=BASE_URL?>assets/js/main.min.js"></script>	
	</footer><!-- .site-footer -->
</div><!-- .site -->
</body>
</html>